// Gestionnaire du panier (copie depuis shop.js pour indépendance)
class CartManager {
    static getCart() {
        const cart = localStorage.getItem('jewelryCart');
        return cart ? JSON.parse(cart) : [];
    }

    static saveCart(cart) {
        localStorage.setItem('jewelryCart', JSON.stringify(cart));
    }

    static removeFromCart(jewelryId) {
        const cart = this.getCart();
        const updatedCart = cart.filter(item => item.id !== jewelryId);
        this.saveCart(updatedCart);
        return updatedCart;
    }

    static updateQuantity(jewelryId, quantity) {
        const cart = this.getCart();
        const item = cart.find(item => item.id === jewelryId);
        
        if (item) {
            if (quantity <= 0) {
                return this.removeFromCart(jewelryId);
            } else {
                item.quantity = quantity;
                this.saveCart(cart);
            }
        }
        
        return cart;
    }

    static getTotal() {
        const cart = this.getCart();
        return cart.reduce((total, item) => total + (item.price * item.quantity), 0);
    }

    static getCartCount() {
        const cart = this.getCart();
        return cart.reduce((total, item) => total + item.quantity, 0);
    }

    static clearCart() {
        localStorage.removeItem('jewelryCart');
    }
}

// Gestionnaire des notifications
class ToastManager {
    static show(message, duration = 3000) {
        const toast = document.getElementById('toast');
        const messageElement = document.getElementById('toastMessage');
        
        messageElement.textContent = message;
        toast.classList.add('show');
        
        setTimeout(() => {
            toast.classList.remove('show');
        }, duration);
    }
}

// Classe principale du panier
class Cart {
    constructor() {
        this.currentView = 'cart'; // 'cart', 'order', 'confirmation'
        this.init();
    }

    init() {
        this.updateCartCount();
        this.renderCartContent();
        this.setupEventListeners();
    }

    setupEventListeners() {
        // Bouton retour au panier
        const backBtn = document.getElementById('backToCart');
        if (backBtn) {
            backBtn.addEventListener('click', () => {
                this.showCart();
            });
        }

        // Formulaire de commande
        const orderForm = document.getElementById('orderForm');
        if (orderForm) {
            orderForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.processOrder();
            });
        }
    }

    updateCartCount() {
        const count = CartManager.getCartCount();
        const cartCountElement = document.getElementById('cartCount');
        if (cartCountElement) {
            cartCountElement.textContent = count;
            cartCountElement.style.display = count > 0 ? 'flex' : 'none';
        }
    }

    renderCartContent() {
        const cartContainer = document.getElementById('cartContainer');
        const cartItems = CartManager.getCart();

        if (cartItems.length === 0) {
            cartContainer.innerHTML = `
                <div class="cart-empty">
                    <div class="empty-icon"><i class="fas fa-shopping-cart" style="color: gold; font-size: 50px;"></i></div>
                    <h2 class="empty-title">Votre panier est vide</h2>
                    <p class="empty-message">Découvrez notre collection de bijoux de luxe</p>
                    <button class="btn-primary" onclick="window.location.href='index.html'">
                        Continuer mes achats
                    </button>
                </div>
            `;
            return;
        }

        const total = CartManager.getTotal();
        const totalItems = cartItems.reduce((sum, item) => sum + item.quantity, 0);

        cartContainer.innerHTML = `
            <div class="cart-items">
                ${cartItems.map(item => `
                    <div class="cart-item">
                        <div class="item-image">
                            <img src="${item.image}" alt="${item.name}">
                        </div>
                        
                        <div class="item-details">
                            <h3 class="item-name">${item.name}</h3>
                            <p class="item-description">${item.description}</p>
                            <p class="item-price">${item.price} € / pièce</p>
                        </div>
                        
                        <div class="quantity-controls">
                            <button class="quantity-btn" ${item.quantity <= 1 ? 'disabled' : ''} 
                                    onclick="cart.updateQuantity(${item.id}, ${item.quantity - 1})">-</button>
                            <span class="quantity-display">${item.quantity}</span>
                            <button class="quantity-btn" 
                                    onclick="cart.updateQuantity(${item.id}, ${item.quantity + 1})">+</button>
                        </div>
                        
                        <div class="item-total">
                            <p class="item-total-price">${(item.price * item.quantity).toFixed(2)} €</p>
                        </div>
                        
                        <button class="remove-btn" onclick="cart.removeItem(${item.id})" title="Supprimer du panier">
                           <i class="fas fa-trash" style="color: red; font-size: 20px; cursor: pointer;"></i>

                        </button>
                    </div>
                `).join('')}
            </div>
            
            <div class="cart-summary">
                <div class="summary-row">
                    <span class="summary-label">Total (${totalItems} articles)</span>
                    <span class="summary-total">${total.toFixed(2)} €</span>
                </div>
                <p class="summary-note">Livraison gratuite pour toute commande</p>
                
                <div class="cart-actions">
                    <button class="btn-secondary" onclick="window.location.href='index.html'">
                        Continuer mes achats
                    </button>
                    <button class="btn-primary" onclick="cart.showOrderForm()">
                        Passer commande
                    </button>
                </div>
            </div>
        `;
    }

    removeItem(itemId) {
        CartManager.removeFromCart(itemId);
        this.updateCartCount();
        this.renderCartContent();
        ToastManager.show('Produit retiré du panier');
    }

    updateQuantity(itemId, newQuantity) {
        CartManager.updateQuantity(itemId, newQuantity);
        this.updateCartCount();
        this.renderCartContent();
    }

    showOrderForm() {
        const cartItems = CartManager.getCart();
        if (cartItems.length === 0) {
            ToastManager.show('Votre panier est vide');
            return;
        }

        // Cacher le panier et afficher le formulaire
        document.getElementById('cartContainer').style.display = 'none';
        document.getElementById('orderFormContainer').style.display = 'block';
        
        // Rendre le récapitulatif de commande
        this.renderOrderSummary();
        this.currentView = 'order';
    }

    showCart() {
        document.getElementById('cartContainer').style.display = 'block';
        document.getElementById('orderFormContainer').style.display = 'none';
        document.getElementById('confirmationContainer').style.display = 'none';
        this.currentView = 'cart';
    }

    renderOrderSummary() {
        const orderSummary = document.getElementById('orderSummary');
        const cartItems = CartManager.getCart();
        const total = CartManager.getTotal();

        orderSummary.innerHTML = `
            <div class="summary-items">
                ${cartItems.map(item => `
                    <div class="summary-item">
                        <div class="summary-item-image">
                            <img src="${item.image}" alt="${item.name}">
                        </div>
                        <div class="summary-item-details">
                            <p class="summary-item-name">${item.name}</p>
                            <p class="summary-item-quantity">Quantité: ${item.quantity}</p>
                        </div>
                        <p class="summary-item-price">${(item.price * item.quantity).toFixed(2)} €</p>
                    </div>
                `).join('')}
            </div>
            
            <div class="summary-divider"></div>
            
            <div class="summary-total-row">
                <span class="summary-total-label">Total</span>
                <span class="summary-total-price">${total.toFixed(2)} €</span>
            </div>
            <p class="summary-note">Livraison gratuite pour toute commande</p>
        `;
    }

    processOrder() {
        const formData = new FormData(document.getElementById('orderForm'));
        const orderData = Object.fromEntries(formData);

        // Validation simple
        const requiredFields = ['fullName', 'email', 'address', 'city', 'postalCode'];
        const missingFields = requiredFields.filter(field => !orderData[field]?.trim());
        
        if (missingFields.length > 0) {
            ToastManager.show('Veuillez remplir tous les champs obligatoires');
            return;
        }

        // Validation email
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(orderData.email)) {
            ToastManager.show('Veuillez entrer une adresse email valide');
            return;
        }

        // Simuler le traitement de la commande
        setTimeout(() => {
            this.showConfirmation(orderData);
        }, 1000);
    }

    showConfirmation(orderData) {
        // Générer un numéro de commande
        const orderNumber = `#JE${Date.now().toString().slice(-6)}`;
        
        // Cacher le formulaire et afficher la confirmation
        document.getElementById('orderFormContainer').style.display = 'none';
        document.getElementById('confirmationContainer').style.display = 'block';
        
        // Mettre à jour le contenu de confirmation
        document.getElementById('confirmationMessage').textContent = 
            `Merci pour votre commande, ${orderData.fullName}. Vous recevrez un email de confirmation à ${orderData.email}.`;
        document.getElementById('orderNumber').textContent = orderNumber;
        
        // Vider le panier
        CartManager.clearCart();
        this.updateCartCount();
        
        this.currentView = 'confirmation';
        ToastManager.show('Commande confirmée avec succès !');
    }
}

// Initialiser le panier au chargement de la page
let cart;
document.addEventListener('DOMContentLoaded', () => {
    cart = new Cart();
});