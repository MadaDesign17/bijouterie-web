// Données des bijoux
const jewelryData = [
    {
        id: 1,
        name: "Collier de Perles Elegance",
        description: "Magnifique collier de perles naturelles avec fermoir en or 18 carats",
        price: 450,
        image: "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDQ2Mzl8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBqZXdlbHJ5fGVufDB8fHx8MTc1Mzg5NDIwN3ww&ixlib=rb-4.1.0&q=85",
        category: "colliers"
    },
    {
        id: 2,
        name: "Collier Or Rose Délicat",
        description: "Collier en or rose 14 carats avec pendentif raffiné",
        price: 320,
        image: "https://images.unsplash.com/photo-1616837874254-8d5aaa63e273?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDQ2Mzl8MHwxfHNlYXJjaHwyfHxsdXh1cnklMjBqZXdlbHJ5fGVufDB8fHx8MTc1Mzg5NDIwN3ww&ixlib=rb-4.1.0&q=85",
        category: "colliers"
    },
    {
        id: 3,
        name: "Bague Saphir Royal",
        description: "Bague en or blanc avec saphir naturel et diamants",
        price: 750,
        image: "https://images.unsplash.com/photo-1606623546924-a4f3ae5ea3e8?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDQ2Mzl8MHwxfHNlYXJjaHwzfHxsdXh1cnklMjBqZXdlbHJ5fGVufDB8fHx8MTc1Mzg5NDIwN3ww&ixlib=rb-4.1.0&q=85",
        category: "bagues"
    },
    {
        id: 4,
        name: "Boucles d'Oreilles Cristal",
        description: "Boucles d'oreilles en or jaune avec cristaux Swarovski",
        price: 280,
        image: "https://images.unsplash.com/photo-1610214354095-684029c14300?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDQ2Mzl8MHwxfHNlYXJjaHw0fHxsdXh1cnklMjBqZXdlbHJ5fGVufDB8fHx8MTc1Mzg5NDIwN3ww&ixlib=rb-4.1.0&q=85",
        category: "boucles"
    },
    {
        id: 5,
        name: "Chaîne Or Massif",
        description: "Chaîne en or 18 carats, maille serpent, longueur 45cm",
        price: 680,
        image: "https://images.unsplash.com/photo-1611107683227-e9060eccd846?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDk1Nzl8MHwxfHNlYXJjaHwxfHxnb2xkJTIwamV3ZWxyeXxlbnwwfHx8fDE3NTM4ODg4MTF8MA&ixlib=rb-4.1.0&q=85",
        category: "colliers"
    },
    {
        id: 6,
        name: "Pendentif Cœur Doré",
        description: "Délicat pendentif cœur en or rose avec chaîne assortie",
        price: 195,
        image: "https://images.unsplash.com/photo-1623321673989-830eff0fd59f?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDk1Nzl8MHwxfHNlYXJjaHwyfHxnb2xkJTIwamV3ZWxyeXxlbnwwfHx8fDE3NTM4ODg4MTF8MA&ixlib=rb-4.1.0&q=85",
        category: "colliers"
    },
    {
        id: 7,
        name: "Bracelet Chaîne Doré",
        description: "Bracelet chaîne en or 14 carats avec fermoir sécurisé",
        price: 380,
        image: "https://images.unsplash.com/photo-1602173574767-37ac01994b2a?crop=entropy&cs=srgb&fm=jpg&ixid=M3w3NDk1Nzl8MHwxfHNlYXJjaHwzfHxnb2xkJTIwamV3ZWxyeXxlbnwwfHx8fDE3NTM4ODg4MTF8MA&ixlib=rb-4.1.0&q=85",
        category: "bracelets"
    },
    {
        id: 8,
        name: "Collection Prestige",
        description: "Ensemble de bijoux dorés : bague, collier et boucles d'oreilles",
        price: 1200,
        image: "https://images.pexels.com/photos/248077/pexels-photo-248077.jpeg",
        category: "ensembles"
    }
];

// Gestionnaire du panier
class CartManager {
    static getCart() {
        const cart = localStorage.getItem('jewelryCart');
        return cart ? JSON.parse(cart) : [];
    }

    static saveCart(cart) {
        localStorage.setItem('jewelryCart', JSON.stringify(cart));
    }

    static addToCart(jewelry) {
        const cart = this.getCart();
        const existingItem = cart.find(item => item.id === jewelry.id);
        
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({ ...jewelry, quantity: 1 });
        }
        
        this.saveCart(cart);
        return cart;
    }

    static getCartCount() {
        const cart = this.getCart();
        return cart.reduce((total, item) => total + item.quantity, 0);
    }
}

// Gestionnaire des notifications
class ToastManager {
    static show(message, duration = 3000) {
        const toast = document.getElementById('toast');
        const messageElement = document.getElementById('toastMessage');
        
        messageElement.textContent = message;
        toast.classList.add('show');
        
        setTimeout(() => {
            toast.classList.remove('show');
        }, duration);
    }
}

// Classe principale de la boutique
class Shop {
    constructor() {
        this.currentCategory = 'all';
        this.init();
    }

    init() {
        this.updateCartCount();
        this.renderProducts();
        this.setupEventListeners();
    }

    setupEventListeners() {
        // Filtres de catégorie
        const filterButtons = document.querySelectorAll('.filter-btn');
        filterButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                const category = e.target.dataset.category;
                this.filterByCategory(category);
            });
        });
    }

    filterByCategory(category) {
        this.currentCategory = category;
        
        // Mettre à jour les boutons actifs
        document.querySelectorAll('.filter-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        document.querySelector(`[data-category="${category}"]`).classList.add('active');
        
        // Re-rendre les produits
        this.renderProducts();
    }

    getFilteredProducts() {
        if (this.currentCategory === 'all') {
            return jewelryData;
        }
        return jewelryData.filter(item => item.category === this.currentCategory);
    }

    renderProducts() {
        const grid = document.getElementById('productsGrid');
        const products = this.getFilteredProducts();
        
        if (products.length === 0) {
            grid.innerHTML = `
                <div style="grid-column: 1/-1; text-align: center; padding: 3rem;">
                    <p style="color: var(--gray); font-size: 1.125rem;">
                        Aucun bijou trouvé dans cette catégorie.
                    </p>
                </div>
            `;
            return;
        }

        grid.innerHTML = products.map(product => `
            <div class="product-card fade-in-up">
                <div class="product-image">
                    <img src="${product.image}" alt="${product.name}" loading="lazy">
                </div>
                <div class="product-content">
                    <h3 class="product-name">${product.name}</h3>
                    <p class="product-description">${product.description}</p>
                    
                    <div class="product-rating">
                        <span class="stars">⭐⭐⭐⭐⭐</span>
                        <span class="rating-text">(4.8)</span>
                    </div>
                    
                    <div class="product-footer">
                        <span class="product-price">${product.price} €</span>
                        <button class="btn-add-cart" onclick="shop.addToCart(${product.id})">
                            <i class="fas fa-shopping-cart" style="font-size: 24px;"></i>
 Ajouter
                        </button>
                    </div>
                </div>
            </div>
        `).join('');
    }

    addToCart(productId) {
        const product = jewelryData.find(item => item.id === productId);
        if (product) {
            CartManager.addToCart(product);
            this.updateCartCount();
            ToastManager.show(`${product.name} ajouté au panier`);
        }
    }

    updateCartCount() {
        const count = CartManager.getCartCount();
        const cartCountElement = document.getElementById('cartCount');
        cartCountElement.textContent = count;
        cartCountElement.style.display = count > 0 ? 'flex' : 'none';
    }
}

// Initialiser la boutique au chargement de la page
let shop;
document.addEventListener('DOMContentLoaded', () => {
    shop = new Shop();
});